/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
      domains: ['elasticbeanstalk-us-east-2-557690622203.s3.us-east-2.amazonaws.com'],
    },
  }

export default nextConfig;
